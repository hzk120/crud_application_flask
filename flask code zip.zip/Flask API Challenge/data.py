"""Routines associated with the application data.
"""

import json
courses = []

def load_data():
    """Load the data from the json file.
    """
    f = open('./json/course.json',) 
    courses.extend(json.load(f))
    #pass


