import requests

def put_api_test():
     response = requests.get("http://localhost:5000/course/2")
     response_body = response.json()

     payload = {
    "description": "M",
    "discount_price": 1,
    "image_path": "",
    "price": 10,
    "title": "Microsoft Excel For Business"
    }
     new_response = requests.put("http://localhost:5000/course/2",data=payload)
     new_response_body = requests.get("http://localhost:5000/course/2").json()
     assert response_body["data"]["description"] == new_response_body["data"]["description"]