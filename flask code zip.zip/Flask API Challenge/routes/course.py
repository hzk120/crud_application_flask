"""Routes for the course resource.
"""

from run import app
from flask import request,make_response, jsonify
from http import HTTPStatus
import data
import random
from datetime import datetime
from six import string_types


@app.route("/course/<int:id>", methods=['GET'])
def get_course(id):
    """Get a course by id.

    :param int id: The record id.
    :return: A single course (see the challenge notes for examples)
    :rtype: object
    """

    """
    -------------------------------------------------------------------------
    Challenge notes:
    -------------------------------------------------------------------------   
    1. Bonus points for not using a linear scan on your data structure.
    """
    # YOUR CODE HERE
    course = next((item for item in data.courses if item["id"] == id), None)
    if course:
        return make_response(jsonify({"data": course}), 200)
    else:
        return make_response(jsonify({"message": f"Course {id} does not exist"}), 404)

@app.route("/course", methods=['GET'])
def get_courses():
    """Get a page of courses, optionally filtered by title words (a list of
    words separated by commas".

    Query parameters: page-number, page-size, title-words
    If not present, we use defaults of page-number=1, page-size=10

    :return: A page of courses (see the challenge notes for examples)
    :rtype: object
    """

    """
    -------------------------------------------------------------------------
    Challenge notes:
    ------------------------------------------------------------------------- 
    1. Bonus points for not using a linear scan, on your data structure, if
       title-words is supplied
    2. Bonus points for returning resulted sorted by the number of words which
       matched, if title-words is supplied.
    3. Bonus points for including performance data on the API, in terms of
       requests/second.
    """
    # YOUR CODE HERE
    try:
        page_number_final = int(request.args.get('page-number')) if request.args.get('page-number') else 1
        page_size_final = int(request.args.get('page-size')) if request.args.get('page-size') else 10
        final_courses = []
        if(request.args.get('title-words')):
            title_words = request.args.get('title-words').split(',')
            for item in data.courses:
                if any(ele in item["title"].split() for ele in title_words):
                    final_courses.append(item)
            # #course = next((item for item in data.courses if any(ele in item["title"].split() for ele in title_words)))
            # if(course):
            #     print("Yes")
            #     final_courses.append(course);
        else:
            final_courses.extend(data.courses)
        record_count = len(final_courses)
        page_count = record_count // page_size_final
        if(record_count > page_size_final):
            final_courses = [final_courses[i * page_size_final:(i + 1) * page_size_final] for i in range((len(final_courses) + page_size_final - 1) // page_size_final )]
            result = final_courses[page_number_final - 1] if not(page_number_final > page_count) else "No More Pages"
        else:
            result = final_courses

        metadata_dict = {"page_count" : page_count,"page_number": page_number_final , "page_size": page_size_final,"record_count": record_count}
        response = {"data": result,"metadata" : metadata_dict}
        return make_response(jsonify(response), 200)
    except Exception as ex:
        #return make_response(jsonify({"message": ex}), 500)
        pass
        


@app.route("/course", methods=['POST'])
def create_course():
    """Create a course.
    :return: The course object (see the challenge notes for examples)
    :rtype: object
    """

    """
    -------------------------------------------------------------------------
    Challenge notes:
    -------------------------------------------------------------------------
    1. Bonus points for validating the POST body fields
    """
    # YOUR CODE HERE
    course_object = request.get_json()
    if(course_object):
        if(not(isinstance(course_object["description"], string_types) and isinstance(course_object["title"], string_types) and isinstance(course_object["on_discount"], bool) and isinstance(course_object["price"], int) and isinstance(course_object["discount_price"], int))):
            return make_response(jsonify({"message": "Invalid Data"}), 400)
        db_id = data.courses[-1]["id"] + 1
        date_updated = str(datetime.now())
        date_created = str(datetime.now())
        course_object["id"] = db_id
        course_object["date_created"] = date_created
        course_object["date_updated"] = date_updated
        print(course_object)
        data.courses.append(course_object)
        return make_response(jsonify({"data": course_object}), 201)
    else:
        return make_response(jsonify({"message": "Invalid Data"}), 400)

@app.route("/course/<int:id>", methods=['PUT'])
def update_course(id):
    """Update a a course.
    :param int id: The record id.
    :return: The updated course object (see the challenge notes for examples)
    :rtype: object
    """

    """
    -------------------------------------------------------------------------
    Challenge notes:
    -------------------------------------------------------------------------
    1. Bonus points for validating the PUT body fields, including checking
       against the id in the URL

    """
    # YOUR CODE HERE
    course_object = dict(request.get_json())
    if(course_object and id > 0):
        # id check
        course = next((item for item in data.courses if item["id"] == id), None)
        if(course):
            # validation check
            string_keys = ["description","title"]
            int_keys = ["discount_price","price"]
            for key in string_keys:
                if(course_object.get(key) and not(isinstance(course_object[key], string_types))):
                    return make_response(jsonify({"message": "Invalid Data"}), 400)
            for key in int_keys:
                if(course_object.get(key) and not(isinstance(course_object[key], int))):
                    return make_response(jsonify({"message": "Invalid Data"}), 400)
            if(course_object.get("on_discount")) and not(isinstance(course_object["on_discount"], bool)):
                return make_response(jsonify({"message": "Invalid Data"}), 400)
        
            date_updated = str(datetime.now())
            course["date_updated"] = date_updated
            for key in course_object:
                course[key] = course_object[key]
            data.courses.append(course)
            return make_response(jsonify({"data": course_object}), 200)
        else:
            return make_response(jsonify({"message": "This id does not exists"}), 400)
    else:
        return make_response(jsonify({"message": "Invalid Data"}), 400)

@app.route("/course/<int:id>", methods=['DELETE'])
def delete_course(id):
    """Delete a course
    :return: A confirmation message (see the challenge notes for examples)
    """
    """
    -------------------------------------------------------------------------
    Challenge notes:
    -------------------------------------------------------------------------
    None
    """
    # YOUR CODE HERE
    course_index = next((index for index,item in enumerate(data.courses) if item["id"] == id), None)
    if course_index:
        del data.courses[course_index]
        return make_response(jsonify({"message": "The specified course was deleted"}), 200)
    else:
        return make_response(jsonify({"message": f"Course {id} does not exist"}), 404)


